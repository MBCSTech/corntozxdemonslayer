<?php if (isset($component)) { $__componentOriginalf2a1b2b34b0a376d40858ac9c2a946a5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2a1b2b34b0a376d40858ac9c2a946a5 = $attributes; } ?>
<?php $component = App\View\Components\SiteLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SiteLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="landing-main">
        <div class="landing-main-cont">
            <div class="main-cont-top">
                <img class="main-cont-ttl" data-aos="fade-up" src="<?php echo e(asset('cari-ttl.png')); ?>">
                <img class="main-cont-pckg display-desktop" data-aos="fade-up" src="<?php echo e(asset('all-pckg.png')); ?>">
                <img class="main-cont-pckg display-mobile" data-aos="fade-up" src="<?php echo e(asset('all-pckg-mobile.png')); ?>">
            </div>
            <div class="prize-cont">
                <img class="prize-cont-ttl" data-aos="fade-up" src="<?php echo e(asset('selesaikan-puzzle.png')); ?>">
                <div class="prize-cont-flex">
                    <div class="prize-cont-list" data-aos="fade-up">
                        <img class="prize-cont-img" data-aos="fade-up" src="<?php echo e(asset('hadiah-utama.png')); ?>">
                        <img class="prize-cont-img" data-aos="fade-up" src="<?php echo e(asset('hadiah-kedua.png')); ?>">
                        <img class="prize-cont-img" data-aos="fade-up" src="<?php echo e(asset('hadiah-ketiga.png')); ?>">
                        <img class="prize-cont-img" data-aos="fade-up" src="<?php echo e(asset('hadiah-mingguan.png')); ?>">
                    </div>
                    <a class="cta-btn" onclick="endModal.showModal()"><img class="btn-redirect display-desktop"
                            src="<?php echo e(asset('puzzle-btn.png')); ?>"></a>
                </div>
            </div>
            <a onclick="endModal.showModal()"><img class="btn-redirect display-mobile" src="<?php echo e(asset('puzzle-btn.png')); ?>"></a>
            <img class="prize-cont-element display-desktop" src="<?php echo e(asset('horse-element-desktop.png')); ?>">
        </div>
        <img class="prize-cont-element display-mobile" src="<?php echo e(asset('horse-element.png')); ?>">
    </div>
    <dialog id="endModal" class="modal">
        <div class="modal-box bg-[#EC4A96]">
            
            <div class="flex flex-col gap-4 py-4 px-8 mt-3 text-2xl text-center text-white">
                <p>Penyertaan untuk peraduan ini telah ditutup.</p>
                <p>Terima kasih.</p>
            </div>
            <div class="modal-action">
                <form method="dialog">
                    <!-- if there is a button in form, it will close the modal -->
                    <input type="text" style="opacity: 0; height: 0; position: absolute; top: 0; right: 0;" tabindex="-1" />
                    <button class="btn btn-sm text-2xl btn-circle btn-ghost text-white absolute right-2 top-2">✕</button>
                </form>
            </div>
        </div>
    </dialog>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2a1b2b34b0a376d40858ac9c2a946a5)): ?>
<?php $attributes = $__attributesOriginalf2a1b2b34b0a376d40858ac9c2a946a5; ?>
<?php unset($__attributesOriginalf2a1b2b34b0a376d40858ac9c2a946a5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2a1b2b34b0a376d40858ac9c2a946a5)): ?>
<?php $component = $__componentOriginalf2a1b2b34b0a376d40858ac9c2a946a5; ?>
<?php unset($__componentOriginalf2a1b2b34b0a376d40858ac9c2a946a5); ?>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init({
        duration: 1200, // Animation duration in milliseconds'
        once: true
    });
</script>
<?php /**PATH C:\Users\fatihi.azmi\Herd\CorntozXOnePiece\resources\views/home.blade.php ENDPATH**/ ?>