<div id="card-body" class="card bg-[#F7941D] text-black w-[90%] lg:w-[97%] xl:w-full m-auto">
    <div class="card-body px-4 lg:pt-[5rem]">
        <h2 class="card-title pt-8 m-auto md:text-3xl lg:text-4xl">ARAHAN</h2>
        <ol id="instruction-list">
            <li id="inst-1">1.&nbsp;&nbsp;Susun kepingan puzzle sehingga membentuk imej lengkap.</li>
            <li id="inst-2">2.&nbsp;Hantar maklumat yang diperlukan bersama resit pembelian RM5 Corntoz 100g/80g anda.</li>
            <li id="inst-3">3.&nbsp;Sila pastikan resit pembelian anda memenuhi info seperti yang ditunjukkan dalam <a href="<?php echo e(asset('receipt_sample.jpg')); ?>" target="_blank" class="underline italic text-[#F9ED32]">CONTOH INI</a> .</li>
            <li id="inst-4">4.&nbsp;Tempoh peraduan: 1 Okt 2024 - 25 Nov 2024.</li>
        </ol>
    </div>
</div>
<?php /**PATH C:\Users\fatihi.azmi\Herd\CorntozXOnePiece\resources\views/components/instruction-card.blade.php ENDPATH**/ ?>