<dialog id="confirm" class="modal lg:w-[60%] absolute md:m-auto">
    <div class="modal-box max-w-[60rem] px-[15px] py-[50px] lg:py-[120px] text-center bg-[#EC4A96]">
        <div id="header" class="arial pb-6 px-4">
            <p class="py-4 arial font-semibold text-white text-[26px]">Terima kasih atas penyertaan anda.<br>Pemenang akan dimaklumkan melalui WhatsApp.</p>
            <p class="py-4 arial font-semibold text-white text-[26px]">Nantikan pengumuman BOOMZ.</p>
            <p class="py-4 arial font-semibold text-white text-[26px]">Kembali ke<br><a href="/" class="text-[#FFF200] underline">halaman utama</a>.</p>
        </div>
    </div>
</dialog>
