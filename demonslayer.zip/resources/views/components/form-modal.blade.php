<dialog id="contest-form" class="modal md:w-[60%] md:m-auto">
    <div class="modal-box max-w-[60rem] p-0 text-center" x-data="{
        nameError: false,
        nameEmpty: false,
        fonError: false,
        fonEmpty: false,
        icError: false,
        icEmpty: false,
        resitError: false,
        fileSizeError: false,
        fileUploaded: false,
        checkboxError: false,
        validateResit() {
            let file = this.$refs.resit.files[0];
            if (file && file.size > 3145728) { // 3MB = 3145728 bytes
                this.fileSizeError = true;
                this.$refs.resit.value = ''; // Clear the input
                setTimeout(() => {
                    this.fileSizeError = false;
                }, 3000);
            } else {
                this.fileUploaded = true;
                setTimeout(() => {
                    this.fileUploaded = false;
                }, 1500);
                this.resitError = false;
                this.fileSizeError = false;
            }
        },
        validateName() {
            const name = this.$refs.nama.value.trim();
            if (!name) {
                this.nameEmpty = true;
                this.nameError = false;
            } else {
                const namePattern = /^[a-zA-Z\s]+$/;
                this.nameError = !namePattern.test(name);
                this.nameEmpty = false;
            }
        },
        validateIC() {
            const ic = this.$refs.no_ic.value.trim();
            const icErrorElement = document.getElementById('icErrorField');
    
            if (!ic) {
                icErrorElement.textContent = 'Sila isi ruangan ini.'; // Empty field error message
                this.icEmpty = true;
                this.icError = false;
            } else {
                const icPattern = /^\d{12}$/; // Exactly 12 digits, no hyphens, letters, or symbols
    
                // Check if there are any letters or non-digit characters
                if (/[^0-9]/.test(ic)) {
                    this.icError = true;
                    icErrorElement.textContent = 'Sila gunakan format nombor IC yang sah tanpa huruf atau tanda (-).';
                } else if (!icPattern.test(ic)) {
                    this.icError = true;
                    icErrorElement.textContent = 'Nombor IC mesti terdiri daripada 12 digit.';
                } else {
                    icErrorElement.textContent = ''; // Clear the error if valid
                    this.icError = false;
                }
                this.icEmpty = false;
            }
        },
        validateFon() {
            const fon = this.$refs.no_fon.value.trim();
            if (!fon) {
                this.fonEmpty = true;
                this.fonError = false;
            } else {
                const fonPattern = /^01\d{8,10}$/;
                this.fonError = !fonPattern.test(fon);
                this.fonEmpty = false;
            }
        },
        validateCheckbox() {
            this.checkboxError = !this.$refs.checkbox.checked;
        },
        validateForm() {
            this.validateName();
            this.validateIC();
            this.validateFon();
            this.validateCheckbox();
            if (!this.$refs.resit.files.length || this.fileSizeError) {
                this.resitError = true;
            }
            return !(this.nameError || this.icError || this.fonError || this.resitError || this.fileSizeError || this.nameEmpty || this.icEmpty || this.fonEmpty || this.checkboxError);
        }
    }">
        <div id="header" class="flex flex-col items-center sm:block">
            <h3 class="arial text-lg font-medium text-[#EC4A96] pt-2">Anda <span class="font-bold arial">HANYA SATU
                    LANGKAH</span><br>sahaja lagi untuk memenangi</h3>
            <h3 class="arial w-[75%] sm:w-full text-lg font-bold">Trip ke Jepun untuk 2 orang atau hadiah lain!</h3>
        </div>
        <div id="body" class="bg-[#EC4A96] arial pb-6 px-4">
            <!-- Error Messages -->
            <p class="py-4 arial font-semibold text-[#F9ED32] lg:hidden">Isi maklumat di bawah dan klik hantar:</p>
            <div x-show=" resitError || fileSizeError" class="bg-red-400 text-white text-sm mt-2">
                <span x-show="resitError" class="hidden lg:block">Sila muatnaik resit anda.</span>
                <span x-show="fileSizeError" class="hidden lg:block">Resit melebihi saiz yang ditetapkan, sila muat naik
                    semula.</span>
            </div>

            <!-- Success Message -->
            <div x-show="fileUploaded" class="hidden lg:block bg-green-400 text-white text-sm mt-2">
                Resit berjaya dimuatnaik.
            </div>
            <div class="lg:flex justify-around relative hidden -left-[3rem]">
                <p class="py-4 arial font-semibold text-[#F9ED32] w-[33%]">Isi maklumat di bawah dan klik hantar:</p>
                <p class="py-4 arial font-semibold text-[#F9ED32] lg:-mr-[2rem]">Muat Naik Resit Anda</p>
            </div>

            <div class="">
                <form method="POST" action="{{ route('contest.store') }}" enctype="multipart/form-data"
                    class="flex flex-col lg:flex-row lg:gap-[1rem] xl:gap-[5rem] px-8 lg:px-4 items-center"
                    @submit.prevent="if (validateForm()) { $el.submit(); }">
                    @csrf
                    <div class="flex flex-col w-full gap-4">
                        {{-- <p id="info"
                            class="py-4 arial font-semibold text-[#F9ED32] hidden lg:hidden lg:mt-[1rem] xl:-mt-[2rem]">
                            Isi maklumat di bawah dan klik hantar:
                        </p> --}}

                        <!-- Name Field -->
                        <label class="mr-auto" for="nama">*NAMA PENUH:</label>
                        <input class="w-full rounded-xl border-none" type="text" id="nama" name="nama"
                            x-ref="nama">
                        <span x-show="nameEmpty" class="bg-red-400 text-white text-sm">Sila isi ruangan ini.</span>
                        <span x-show="nameError" class="bg-red-400 text-white text-sm">Sila gunakan huruf
                            sahaja.</span>

                        <!-- IC Field -->
                        <label class="mr-auto" for="no_ic">*NO. IC:</label>
                        <input class="w-full rounded-xl border-none" maxlength="12" type="text" id="no_ic"
                            name="no_ic" x-ref="no_ic">
                        <span x-show="icEmpty" class="bg-red-400 text-white text-sm">Sila isi ruangan ini.</span>
                        <span x-show="icError" id="icErrorField" class="bg-red-400 text-white text-sm">Sila panjangkan
                            teks ini kepada 12
                            aksara.</span>

                        <!-- Phone Number Field -->
                        <label class="mr-auto" for="no_fon">*NO. TELEFON:</label>
                        <input class="w-full rounded-xl border-none" maxlength="12" type="text" id="no_fon"
                            name="no_fon" x-ref="no_fon">
                        <span x-show="fonEmpty" class="bg-red-400 text-white text-sm">Sila isi ruangan ini.</span>
                        <span x-show="fonError" id="noErrorField" class="bg-red-400 text-white text-sm">Sila gunakan
                            format nombor telefon
                            yang sah, cth. 012.</span>

                        <p class="text-sm arial text-white text-left italic my-6">* Pastikan nombor anda dapat dihubungi
                            melalui WhatsApp</p>
                    </div>

                    <div id="white-border" class="w-full h-[2px] lg:w-[3px] lg:h-[26rem] bg-white"></div>

                    <!-- Resit Upload Section -->
                    <div class="w-full">
                        <div x-show=" resitError || fileSizeError"
                            class="bg-red-400 text-white text-sm mt-2 w-full lg:hidden">
                            <span x-show="resitError">Sila muatnaik resit anda.</span>
                            <span x-show="fileSizeError">Resit melebihi saiz yang ditetapkan, sila muat naik
                                semula.</span>
                        </div>
                        <div x-show="fileUploaded" class="lg:hidden bg-green-400 text-white w-full text-sm mt-2">
                            Resit berjaya dimuatnaik.
                        </div>
                        <p class="py-4 arial font-semibold lg:hidden text-[#F9ED32]">Muat Naik Resit Anda</p>
                        <label class="cursor-pointer">
                            <input id="resit" name="resit" type="file" accept=".png, .jpg, .jpeg, .pdf"
                                x-ref="resit" @change="validateResit">
                            <img src="/upload-btn.png" alt="">
                        </label>
                        <ol id="resit-disc" class="w-[17rem] md:w-full">
                            <li>Anda mesti membeli Corntoz 100g/80g bernilai RM5</li>
                            <li>Pastikan resit jelas dan tunjukkan info seperti dalam <a href="{{ asset('receipt_sample.jpg') }}" target="_blank" class="underline">CONTOH INI</a></li>
                            <li>Tiada resit gabungan</li>
                            <li>Hanya menerima format Jpeg, PNG, dan PDF sahaja, dengan saiz fail tidak melebihi 3MB
                            </li>
                        </ol>

                        <!-- Submit Button -->
                        <input class="my-4 w-[78%]" type="image" src="/send-btn.png">
                        <div x-show="checkboxError" class="bg-red-400 mb-4 text-white text-sm">Sila tandakan kotak persetujuan
                            terma & syarat.</div>
                        <div class="form-control flex-row" style="margin-left: 1.5rem">
                            <input type="checkbox" class="checkbox" x-ref="checkbox" />
                            <ol style="padding-left: 1.2rem">
                                <li> Anda bersetuju dengan <a class="underline"
                                        href="{{ asset('TC_PERADUAN_MAMEE_CORNTOZ_CARI-CARI_BOOMZZLE_Cantum_dan_Menang!.pdf') }}"
                                        target="_blank">Terma
                                        & Syarat</a> yang disediakan.</li>
                            </ol>
                        </div>
                        
                    </div>
                </form>
            </div>
        </div>
    </div>
</dialog>
