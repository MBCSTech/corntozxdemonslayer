<x-site-layout>
    <div id="puzzle-section" class="flex flex-col">
        <div id="instruction" class="m-auto mt-32 lg:mt-[18rem] relative">
            <x-instruction-card />
            <x-pinko-puzzle />
            <x-puzzle-title />
        </div>
        <div id="puzzle-container-mobile" class="relative w-full flex justify-center lg:hidden">
            <x-puzzle-overlay />
            <div id="puzzle" class=""></div>
            <img id="completed-puzzle" src="{{ asset('storage/puzzle4.jpg')}}" alt="">
        </div>
        <div id="puzzle-container-desktop" class="relative w-full justify-center hidden lg:flex">
            <x-puzzle-overlay-desktop />
            <div id="puzzle-desktop" class=""></div>
            <img id="completed-puzzle-desktop" src="{{ asset('storage/puzzle4.jpg')}}" alt="">
        </div>
        <x-form-modal />
    </div>
</x-site-layout>

<script type="module">
    let puzzleImage = new Image()
    puzzleImage.src = "storage/puzzle4-pic.jpg"
    puzzleImage.onload = () => {
        const pinko = new headbreaker.Canvas('puzzle', {
            width: 450,
            height: 850,
            pieceSize: {
                x: 152,
                y: 101
            },
            proximity: 25,
            borderFill: 8,
            strokeWidth: 1.5,
            lineSoftness: 0.18,
            image: puzzleImage,
            fixed: true,
            outline: new headbreaker.outline.Rounded(),
            preventOffstageDrag: true
        });

        // Adjust images to fit the puzzle height
        pinko.adjustImagesToPuzzleHeight();

        // Autogenerate the puzzle pieces
        pinko.autogenerate({
            horizontalPiecesCount: 2,
            verticalPiecesCount: 3
        });

        // Assign metadata to each piece for row and column
        pinko.puzzle.pieces.forEach((piece, index) => {
            const row = Math.floor(index / 2) + 1; // Calculate row based on index
            const column = (index % 2) + 1; // Calculate column based on index
            piece.metadata.row = row;
            piece.metadata.column = column;
            piece.metadata.id = `piece-${row}-${column}`;
            piece.metadata.class = 'puzzle-pieces';
        });

        // Define valid connections
        const validConnections = {
            '1,1': ['1,2', '2,1'],
            '1,2': ['1,1', '2,2'],
            '2,1': ['1,1', '2,2', '3,1'],
            '2,2': ['2,1', '1,2', '3,2'],
            '3,1': ['2,1', '3,2'],
            '3,2': ['2,2', '3,1']
        };

        // Define custom connection requirement based on row and column metadata
        pinko.puzzle.attachConnectionRequirement((one, other) => {
            const keyOne = `${one.metadata.row},${one.metadata.column}`;
            const keyOther = `${other.metadata.row},${other.metadata.column}`;

            if ((keyOne === '2,1' && keyOther === '2,2') || (keyOne === '2,2' && keyOther === '2,1')) {
                if (Math.abs(one.metadata.currentPosition.y - other.metadata.currentPosition.y) > 10) {
                    return false;
                }
            }
            // Check if the connection is valid
            return validConnections[keyOne]?.includes(keyOther);
        });

        // Shuffle the grid
        pinko.shuffleGrid();

        // Translate pieces slightly to create an initial offset
        pinko.puzzle.pieces.forEach(piece => piece.translate(-22, 330));

        pinko.puzzle.forceDisconnectionWhileDragging()
        pinko.registerKeyboardGestures();


        // Draw the puzzle on the canvas
        pinko.draw();

        // Attach a solved validator to handle when the puzzle is solved
        pinko.attachSolvedValidator();

        // Define what happens when the puzzle is solved
        pinko.onValid(() => {
            setTimeout(() => {
                document.getElementById('completed-puzzle').setAttribute("class", "active");
                document.getElementById('puzzle-overlay').setAttribute("class", "disappear");
                document.getElementById('puzzle').setAttribute("class", "disappear");
            }, 1500);
            setTimeout(() => {
                document.getElementById('contest-form').showModal();
            }, 3000);
        });


        const pinkoDesktop = new headbreaker.Canvas('puzzle-desktop', {
            width: 900,
            height: 575,
            pieceSize: {
                x: 151,
                y: 100.5
            },
            proximity: 25,
            borderFill: 8,
            strokeWidth: 1.5,
            lineSoftness: 0.18,
            image: puzzleImage,
            fixed: true,
            outline: new headbreaker.outline.Rounded(),
            preventOffstageDrag: true,
            // dragMode: 'ForceDisconnection'
        });



        // Adjust images to fit the puzzle height
        // pinkoDesktop.adjustImagesToPuzzleHeight();
        pinkoDesktop.adjustImagesToPuzzleWidth();

        // Autogenerate the puzzle pieces
        pinkoDesktop.autogenerate({
            horizontalPiecesCount: 2,
            verticalPiecesCount: 3
        });

        // Assign metadata to each piece for row and column
        pinkoDesktop.puzzle.pieces.forEach((piece, index) => {
            const row = Math.floor(index / 2) + 1; // Calculate row based on index
            const column = (index % 2) + 1; // Calculate column based on index
            piece.metadata.row = row;
            piece.metadata.column = column;
            piece.metadata.id = `piece-${row}-${column}`;
            piece.metadata.class = 'puzzle-pieces';

        });

        // Define valid connections
        const validConnectionsDesktop = {
            '1,1': ['1,2', '2,1'],
            '1,2': ['1,1', '2,2'],
            '2,1': ['1,1', '2,2', '3,1'],
            '2,2': ['2,1', '1,2', '3,2'],
            '3,1': ['2,1', '3,2'],
            '3,2': ['2,2', '3,1']
        };

        // Define custom connection requirement based on row and column metadata
        pinkoDesktop.puzzle.attachConnectionRequirement((one, other) => {
            const keyOne = `${one.metadata.row},${one.metadata.column}`;
            const keyOther = `${other.metadata.row},${other.metadata.column}`;

            if ((keyOne === '2,1' && keyOther === '2,2') || (keyOne === '2,2' && keyOther === '2,1')) {
                if (Math.abs(one.metadata.currentPosition.y - other.metadata.currentPosition.y) > 10) {
                    return false;
                }
            }
            // Check if the connection is valid
            return validConnectionsDesktop[keyOne]?.includes(keyOther);
        });

        // Shuffle the grid
        pinkoDesktop.shuffleGrid();

        // Translate pieces slightly to create an initial offset
        pinkoDesktop.puzzle.pieces.forEach(piece => piece.translate(-10, 20));
        pinkoDesktop.puzzle.forceDisconnectionWhileDragging()
        pinkoDesktop.registerKeyboardGestures();

        // Draw the puzzle on the canvas
        pinkoDesktop.draw();

        // Attach a solved validator to handle when the puzzle is solved
        pinkoDesktop.attachSolvedValidator();

        // Define what happens when the puzzle is solved
        pinkoDesktop.onValid(() => {
            setTimeout(() => {
                document.getElementById('completed-puzzle-desktop').setAttribute("class", "active");
                document.getElementById('puzzle-overlay-desktop').setAttribute("class",
                    "disappear");
                document.getElementById('puzzle-desktop').setAttribute("class", "disappear");
            }, 1500);
            setTimeout(() => {
                document.getElementById('contest-form').showModal();
            }, 3000);
        });

    }
</script>
