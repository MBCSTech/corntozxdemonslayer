<div>
    <!-- Order your soul. Reduce your wants. - Augustine -->
</div><?php /**PATH C:\Users\fatihi.azmi\Herd\CorntozXOnePiece\resources\views/components/site-layout.blade.php ENDPATH**/ ?>