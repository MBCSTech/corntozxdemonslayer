<div class="drawer">
    <input id="my-drawer-3" type="checkbox" class="drawer-toggle" />
    <div class="drawer-content flex flex-col">
        <!-- Navbar -->
        <div class="navbar z-10 min-h-[6rem] bg-[#EC4A96] lg:bg-transparent w-full justify-between px-[1rem] md:px-[4rem] lg:justify-center">
            <div class="flex-none pb-4 lg:hidden text-white mr-2">
                <label for="my-drawer-3" aria-label="open sidebar" class="btn btn-square btn-ghost">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                        class="inline-block scale-[1.4] md:scale-[1] h-[3.5rem] w-[3.5rem] stroke-current">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 6h16M4 12h16M4 18h16"></path>
                    </svg>
                </label>
            </div>
            <div class="hidden flex-none md:text-center lg:block">
                <ul class="menu menu-horizontal text-white">
                    <!-- Navbar menu content here -->
                    <li><a href="/">Halaman Utama</a></li>
                    <li><a href="https://mamee.com/our-worlds/snacks/corntoz/">Tentang Corntoz</a></li>
                    <li><a href="<?php echo e(asset('TC_PERADUAN_MAMEE_CORNTOZ_CARI-CARI_BOOMZZLE_Cantum_dan_Menang!.pdf')); ?>" target="_blank">Terma & Syarat</a></li>
                </ul>
            </div>
            <img src="<?php echo e(asset('logo.png')); ?>" alt="logos" class="w-[80%] sm:w-[60%] md:w-[40%] lg:w-[15%]">
        </div>
    </div>
    <div class="drawer-side z-10">
        <label for="my-drawer-3" aria-label="close sidebar" class="drawer-overlay"></label>
        <ul class="menu bg-[#EC4A96] text-white min-h-full w-80 p-4 gap-5">
            <!-- Sidebar content here -->
            <label for="my-drawer-3" aria-label="close sidebar" class="flex justify-end">
                <svg id="close-drawer" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                    stroke-width="1.5" stroke="currentColor" class="size-8">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" />
                </svg>

            </label>
            <li><a href="/">Halaman Utama</a></li>
            <div class="w-[86%] relative left-[18px] h-[2px] bg-white"></div>
            <li><a href="https://mamee.com/our-worlds/snacks/corntoz/">Tentang Corntoz</a></li>
            <div class="w-[86%] relative left-[18px] h-[2px] bg-white"></div>
            <li><a href="<?php echo e(asset('TC_PERADUAN_MAMEE_CORNTOZ_CARI-CARI_BOOMZZLE_Cantum_dan_Menang!.pdf')); ?>" target="_blank">Terma & Syarat</a></li>
            <div class="w-[86%] relative left-[18px] h-[2px] bg-white"></div>
        </ul>
    </div>
</div>
<?php /**PATH C:\Users\fatihi.azmi\Herd\CorntozXOnePiece\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>