<dialog id="contest-form-desktop" class="modal w-[60%] m-auto">
    <div class="modal-box max-w-[60rem] p-0 text-center" x-data="{
        resitError: false,
        fileSizeError: false,
        fileUploaded: false,
        validateResit() {
            let file = this.$refs.resit.files[0];
            if (file && file.size > 3145728) { // 3MB = 3145728 bytes
                this.fileSizeError = true;
                this.$refs.resit.value = ''; // Clear the input
            } else {
                this.fileUploaded = true;
                this.resitError = false;
                this.fileSizeError = false;
            }
        }
    }">
        <div id="header" class="">
            <h3 class="arial text-lg font-medium text-[#EC4A96] pt-2">Anda <span class="font-bold arial">HANYA SATU
                    LANGKAH</span><br>sahaja lagi untuk memenangi</h3>
            <h3 class="arial text-lg font-bold">Trip ke Jepun untuk 2 orang atau hadiah lain!</h3>
        </div>
        <div id="body" class="bg-[#EC4A96] arial pb-6 px-4">
            <?php if($errors->any()): ?>
                <div class="bg-red-400 text-white">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        // Reset the form if there's a success message
                        document.querySelector('form').reset();
                    });
                </script>
            <?php endif; ?>

            <div x-show="resitError || fileSizeError" class= "bg-red-400 text-white text-sm mt-2">
                <span x-show="resitError">Sila lampirkan resit anda.</span>
                <span x-show="fileSizeError">Resit melebihi saiz yang ditetapkan, sila muatnaik kembali.</span>
            </div>
            <div x-show="fileUploaded" class="bg-green-400 text-white text-sm mt-2">
                Resit berjaya dimuatnaik.
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        // Reset the form if there's a success message
                        document.querySelector('form').reset();
                    });
                </script>
            <?php endif; ?>

            <div class="">
                <form method="POST" action="<?php echo e(route('contest.store')); ?>" enctype="multipart/form-data"
                    class="flex gap-[5rem] px-8 items-center"
                    @submit.prevent="if (!$refs.resit.files.length || fileSizeError) { resitError = true; return; } $el.submit();">
                    <?php echo csrf_field(); ?>
                    <div class="flex flex-col w-full">
                        <p class="py-4 arial font-semibold text-[#F9ED32]">Isi maklumat di bawah dan klik hantar:</p>

                        <label class="mr-auto" for="nama">NAMA PENUH:</label>
                        <input required class="w-full rounded-xl border-none" type="text" id="nama"
                            name="nama" maxlength="100" pattern="[A-Za-z\s\-.,']+"
                            oninvalid="this.setCustomValidity('Sila gunakan huruf sahaja.')"
                            oninput="this.setCustomValidity('Sila isi ruangan ini.')">
                        <label class="mr-auto" for="no_ic">NO. IC:</label>
                        <input required class="w-full rounded-xl border-none" type="text" id="no_ic"
                            name="no_ic" minlength="12" maxlength="12" pattern="\d*"
                            oninvalid="this.setCustomValidity('Sila gunakan format nombor IC yang sah tanpa tanda (-).')"
                            oninput="this.setCustomValidity('Sila panjangkan teks ini kepada 12 aksara atau lebih.')">
                        <label class="mr-auto" for="no_fon">NO. TELEFON:</label>
                        <input required class="w-full rounded-xl border-none" type="text" id="no_fon"
                            name="no_fon" minlength="10" maxlength="12" pattern="01\d{8,10}"
                            oninvalid="this.setCustomValidity('Sila gunakan format nombor telefon yang sah, cth. 012.')"
                            oninput="this.setCustomValidity('Sila ikut format yang diminta')">
                        <p class="text-sm arial text-white text-left italic my-6">* Pastikan nombor anda dapat dihubungi
                            melalui WhatsApp</p>
                    </div>
                    <div id="white-border" class="w-[3px] h-[26rem] bg-white"></div>
                    <div>
                        <p class="py-4 arial font-semibold text-[#F9ED32]">Muat Naik Resit Anda</p>
                        <label class="cursor-pointer">
                            <input id="resit" name="resit" type="file" accept=".png, .jpg, .jpeg, .pdf"
                                x-ref="resit" @change="validateResit">
                            <img src="/upload-btn.png" alt="">
                        </label>
                        <ol>
                            <li>Anda mesti membeli Corntoz 100g/80g bernilai RM5</li>
                            <li>Pastikan resit boleh dibaca</li>
                            <li>Tiada resit gabungan</li>
                            <li>Hanya menerima format Jpeg, PNG, dan PDF sahaja, dengan saiz fail tidak melebihi 3MB
                            </li>
                        </ol>
                        <input class="my-4 w-[78%]" type="image" src="/send-btn.png">
                        <ol>
                            <li>Dengan menghantar, anda bersetuju dengan Terma dan Syarat yang disediakan.</li>
                        </ol>
                    </div>
                </form>
            </div>
        </div>
    </div>
</dialog>


<script>
    $(function() {
        $('#resit').on('change', function(e) {
            let size = this.files[0].size;

            // if (this.files.length > 0) {
            //     alert('Resit berjaya dimuatnaik')
            // }
        });
    })
</script>
<?php /**PATH C:\Users\fatihi.azmi\Herd\CorntozXOnePiece\resources\views/components/form-modal-desktop.blade.php ENDPATH**/ ?>