<!-- Open the modal using ID.showModal() method -->

<dialog id="receipt-modal" class="modal">
  <div class="modal-box">
    <img id="receiptImage" style="display: none; max-width: 100%;" alt="Resit">
    <canvas id="receiptPdfCanvas" style="display: none; max-width: 100%;"></canvas>
    <div class="modal-action justify-between">
      <form method="dialog">
        <!-- if there is a button in form, it will close the modal -->
        <button class="btn">Close</button>
      </form>
      <a id="download-button" download href="#" class="btn btn-primary">Download</a>
    </div>
  </div>
</dialog><?php /**PATH C:\Users\fatihi.azmi\Herd\corntozxdemonslayer\resources\views/components/image-modal.blade.php ENDPATH**/ ?>