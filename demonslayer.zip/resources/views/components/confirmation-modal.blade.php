<!-- Open the modal using ID.showModal() method -->
{{-- <button class="btn" onclick="my_modal_1.showModal()">open modal</button> --}}
<dialog id="confirmation-modal" class="modal">
    <div class="modal-box p-0 text-center">
        <div id="body" class="bg-[#EC4A96] arial py-6 px-4 flex flex-col gap-4">
            <p>Terima kasih atas penyertaan anda</p>
            <p>Pemenang akan dimaklumkan</p>
            <p>melalui WhatsApp</p>
            <p>Terima kasih atas penyertaan anda</p>
            <p>Kembali ke</p>
            <p><a href="/">halaman utama</a></p>
        </div>
    </div>
</dialog>
