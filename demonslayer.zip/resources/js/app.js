import './bootstrap';

import Alpine from 'alpinejs';

import headbreaker from 'headbreaker'

window.Alpine = Alpine;

window.headbreaker = headbreaker;

Alpine.start();
