<?php if (isset($component)) { $__componentOriginalf2a1b2b34b0a376d40858ac9c2a946a5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2a1b2b34b0a376d40858ac9c2a946a5 = $attributes; } ?>
<?php $component = App\View\Components\SiteLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SiteLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div id="puzzle-section" class="flex flex-col">
        <div id="instruction" class="m-auto mt-32 lg:mt-[18rem] relative">
            <?php if (isset($component)) { $__componentOriginala465f5c3040b64eb9a621490cf1ff212 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala465f5c3040b64eb9a621490cf1ff212 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.instruction-card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('instruction-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala465f5c3040b64eb9a621490cf1ff212)): ?>
<?php $attributes = $__attributesOriginala465f5c3040b64eb9a621490cf1ff212; ?>
<?php unset($__attributesOriginala465f5c3040b64eb9a621490cf1ff212); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala465f5c3040b64eb9a621490cf1ff212)): ?>
<?php $component = $__componentOriginala465f5c3040b64eb9a621490cf1ff212; ?>
<?php unset($__componentOriginala465f5c3040b64eb9a621490cf1ff212); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalda02bebabbbd9928cdac38be7af73930 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda02bebabbbd9928cdac38be7af73930 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pinko-puzzle','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pinko-puzzle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda02bebabbbd9928cdac38be7af73930)): ?>
<?php $attributes = $__attributesOriginalda02bebabbbd9928cdac38be7af73930; ?>
<?php unset($__attributesOriginalda02bebabbbd9928cdac38be7af73930); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda02bebabbbd9928cdac38be7af73930)): ?>
<?php $component = $__componentOriginalda02bebabbbd9928cdac38be7af73930; ?>
<?php unset($__componentOriginalda02bebabbbd9928cdac38be7af73930); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal0bb59c7df63fa43ca4b1edbdf7f92329 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0bb59c7df63fa43ca4b1edbdf7f92329 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.puzzle-title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('puzzle-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0bb59c7df63fa43ca4b1edbdf7f92329)): ?>
<?php $attributes = $__attributesOriginal0bb59c7df63fa43ca4b1edbdf7f92329; ?>
<?php unset($__attributesOriginal0bb59c7df63fa43ca4b1edbdf7f92329); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0bb59c7df63fa43ca4b1edbdf7f92329)): ?>
<?php $component = $__componentOriginal0bb59c7df63fa43ca4b1edbdf7f92329; ?>
<?php unset($__componentOriginal0bb59c7df63fa43ca4b1edbdf7f92329); ?>
<?php endif; ?>
        </div>
        <div id="puzzle-container-mobile" class="relative w-full flex justify-center lg:hidden">
            <?php if (isset($component)) { $__componentOriginale5e1eefb0384d34f1376733591792685 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale5e1eefb0384d34f1376733591792685 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.puzzle-overlay','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('puzzle-overlay'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale5e1eefb0384d34f1376733591792685)): ?>
<?php $attributes = $__attributesOriginale5e1eefb0384d34f1376733591792685; ?>
<?php unset($__attributesOriginale5e1eefb0384d34f1376733591792685); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale5e1eefb0384d34f1376733591792685)): ?>
<?php $component = $__componentOriginale5e1eefb0384d34f1376733591792685; ?>
<?php unset($__componentOriginale5e1eefb0384d34f1376733591792685); ?>
<?php endif; ?>
            <div id="puzzle" class=""></div>
            <img id="completed-puzzle" src="<?php echo e(asset('storage/puzzle4.jpg')); ?>" alt="">
        </div>
        <div id="puzzle-container-desktop" class="relative w-full justify-center hidden lg:flex">
            <?php if (isset($component)) { $__componentOriginalf0ba4bc1f7e06f46ed99d58a23ebfed4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf0ba4bc1f7e06f46ed99d58a23ebfed4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.puzzle-overlay-desktop','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('puzzle-overlay-desktop'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf0ba4bc1f7e06f46ed99d58a23ebfed4)): ?>
<?php $attributes = $__attributesOriginalf0ba4bc1f7e06f46ed99d58a23ebfed4; ?>
<?php unset($__attributesOriginalf0ba4bc1f7e06f46ed99d58a23ebfed4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf0ba4bc1f7e06f46ed99d58a23ebfed4)): ?>
<?php $component = $__componentOriginalf0ba4bc1f7e06f46ed99d58a23ebfed4; ?>
<?php unset($__componentOriginalf0ba4bc1f7e06f46ed99d58a23ebfed4); ?>
<?php endif; ?>
            <div id="puzzle-desktop" class=""></div>
            <img id="completed-puzzle-desktop" src="<?php echo e(asset('storage/puzzle4.jpg')); ?>" alt="">
        </div>
        <?php if (isset($component)) { $__componentOriginaldf85e6552b95df616d59caebcbf2473d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf85e6552b95df616d59caebcbf2473d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf85e6552b95df616d59caebcbf2473d)): ?>
<?php $attributes = $__attributesOriginaldf85e6552b95df616d59caebcbf2473d; ?>
<?php unset($__attributesOriginaldf85e6552b95df616d59caebcbf2473d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf85e6552b95df616d59caebcbf2473d)): ?>
<?php $component = $__componentOriginaldf85e6552b95df616d59caebcbf2473d; ?>
<?php unset($__componentOriginaldf85e6552b95df616d59caebcbf2473d); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2a1b2b34b0a376d40858ac9c2a946a5)): ?>
<?php $attributes = $__attributesOriginalf2a1b2b34b0a376d40858ac9c2a946a5; ?>
<?php unset($__attributesOriginalf2a1b2b34b0a376d40858ac9c2a946a5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2a1b2b34b0a376d40858ac9c2a946a5)): ?>
<?php $component = $__componentOriginalf2a1b2b34b0a376d40858ac9c2a946a5; ?>
<?php unset($__componentOriginalf2a1b2b34b0a376d40858ac9c2a946a5); ?>
<?php endif; ?>

<script type="module">
    let puzzleImage = new Image()
    puzzleImage.src = "storage/puzzle4-pic.jpg"
    puzzleImage.onload = () => {
        const pinko = new headbreaker.Canvas('puzzle', {
            width: 450,
            height: 850,
            pieceSize: {
                x: 152,
                y: 101
            },
            proximity: 25,
            borderFill: 8,
            strokeWidth: 1.5,
            lineSoftness: 0.18,
            image: puzzleImage,
            fixed: true,
            outline: new headbreaker.outline.Rounded(),
            preventOffstageDrag: true
        });

        // Adjust images to fit the puzzle height
        pinko.adjustImagesToPuzzleHeight();

        // Autogenerate the puzzle pieces
        pinko.autogenerate({
            horizontalPiecesCount: 2,
            verticalPiecesCount: 3
        });

        // Assign metadata to each piece for row and column
        pinko.puzzle.pieces.forEach((piece, index) => {
            const row = Math.floor(index / 2) + 1; // Calculate row based on index
            const column = (index % 2) + 1; // Calculate column based on index
            piece.metadata.row = row;
            piece.metadata.column = column;
            piece.metadata.id = `piece-${row}-${column}`;
            piece.metadata.class = 'puzzle-pieces';
        });

        // Define valid connections
        const validConnections = {
            '1,1': ['1,2', '2,1'],
            '1,2': ['1,1', '2,2'],
            '2,1': ['1,1', '2,2', '3,1'],
            '2,2': ['2,1', '1,2', '3,2'],
            '3,1': ['2,1', '3,2'],
            '3,2': ['2,2', '3,1']
        };

        // Define custom connection requirement based on row and column metadata
        pinko.puzzle.attachConnectionRequirement((one, other) => {
            const keyOne = `${one.metadata.row},${one.metadata.column}`;
            const keyOther = `${other.metadata.row},${other.metadata.column}`;

            if ((keyOne === '2,1' && keyOther === '2,2') || (keyOne === '2,2' && keyOther === '2,1')) {
                if (Math.abs(one.metadata.currentPosition.y - other.metadata.currentPosition.y) > 10) {
                    return false;
                }
            }
            // Check if the connection is valid
            return validConnections[keyOne]?.includes(keyOther);
        });

        // Shuffle the grid
        pinko.shuffleGrid();

        // Translate pieces slightly to create an initial offset
        pinko.puzzle.pieces.forEach(piece => piece.translate(-22, 330));

        pinko.puzzle.forceDisconnectionWhileDragging()
        pinko.registerKeyboardGestures();


        // Draw the puzzle on the canvas
        pinko.draw();

        // Attach a solved validator to handle when the puzzle is solved
        pinko.attachSolvedValidator();

        // Define what happens when the puzzle is solved
        pinko.onValid(() => {
            setTimeout(() => {
                document.getElementById('completed-puzzle').setAttribute("class", "active");
                document.getElementById('puzzle-overlay').setAttribute("class", "disappear");
                document.getElementById('puzzle').setAttribute("class", "disappear");
            }, 1500);
            setTimeout(() => {
                document.getElementById('contest-form').showModal();
            }, 3000);
        });


        const pinkoDesktop = new headbreaker.Canvas('puzzle-desktop', {
            width: 900,
            height: 575,
            pieceSize: {
                x: 151,
                y: 100.5
            },
            proximity: 25,
            borderFill: 8,
            strokeWidth: 1.5,
            lineSoftness: 0.18,
            image: puzzleImage,
            fixed: true,
            outline: new headbreaker.outline.Rounded(),
            preventOffstageDrag: true,
            // dragMode: 'ForceDisconnection'
        });



        // Adjust images to fit the puzzle height
        // pinkoDesktop.adjustImagesToPuzzleHeight();
        pinkoDesktop.adjustImagesToPuzzleWidth();

        // Autogenerate the puzzle pieces
        pinkoDesktop.autogenerate({
            horizontalPiecesCount: 2,
            verticalPiecesCount: 3
        });

        // Assign metadata to each piece for row and column
        pinkoDesktop.puzzle.pieces.forEach((piece, index) => {
            const row = Math.floor(index / 2) + 1; // Calculate row based on index
            const column = (index % 2) + 1; // Calculate column based on index
            piece.metadata.row = row;
            piece.metadata.column = column;
            piece.metadata.id = `piece-${row}-${column}`;
            piece.metadata.class = 'puzzle-pieces';

        });

        // Define valid connections
        const validConnectionsDesktop = {
            '1,1': ['1,2', '2,1'],
            '1,2': ['1,1', '2,2'],
            '2,1': ['1,1', '2,2', '3,1'],
            '2,2': ['2,1', '1,2', '3,2'],
            '3,1': ['2,1', '3,2'],
            '3,2': ['2,2', '3,1']
        };

        // Define custom connection requirement based on row and column metadata
        pinkoDesktop.puzzle.attachConnectionRequirement((one, other) => {
            const keyOne = `${one.metadata.row},${one.metadata.column}`;
            const keyOther = `${other.metadata.row},${other.metadata.column}`;

            if ((keyOne === '2,1' && keyOther === '2,2') || (keyOne === '2,2' && keyOther === '2,1')) {
                if (Math.abs(one.metadata.currentPosition.y - other.metadata.currentPosition.y) > 10) {
                    return false;
                }
            }
            // Check if the connection is valid
            return validConnectionsDesktop[keyOne]?.includes(keyOther);
        });

        // Shuffle the grid
        pinkoDesktop.shuffleGrid();

        // Translate pieces slightly to create an initial offset
        pinkoDesktop.puzzle.pieces.forEach(piece => piece.translate(-10, 20));
        pinkoDesktop.puzzle.forceDisconnectionWhileDragging()
        pinkoDesktop.registerKeyboardGestures();

        // Draw the puzzle on the canvas
        pinkoDesktop.draw();

        // Attach a solved validator to handle when the puzzle is solved
        pinkoDesktop.attachSolvedValidator();

        // Define what happens when the puzzle is solved
        pinkoDesktop.onValid(() => {
            setTimeout(() => {
                document.getElementById('completed-puzzle-desktop').setAttribute("class", "active");
                document.getElementById('puzzle-overlay-desktop').setAttribute("class",
                    "disappear");
                document.getElementById('puzzle-desktop').setAttribute("class", "disappear");
            }, 1500);
            setTimeout(() => {
                document.getElementById('contest-form').showModal();
            }, 3000);
        });

    }
</script>
<?php /**PATH C:\Users\fatihi.azmi\Herd\CorntozXOnePiece\resources\views/puzzle.blade.php ENDPATH**/ ?>